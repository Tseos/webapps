package com.example.model;

import java.util.List;

public class EshopingExpert {

	public List<String> getBrands(String c) {
		// TODO Auto-generated method stub
		return null;
	}

}
