package com.example.web;

import java.io.IOException;
import java.util.List;

import com.example.model.EshopingExpert;

public class EshopingSelect extends HttpServlet {

	/**
	 * Problem
	 */
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;

	public void doPost (HttpServletRequest request,HttpServletResponse response)
			throws IOException, ServletException {

		String c = request.getParameter("sort");
		EshopingExpert be = new EshopingExpert ();
		List<String> result = be.getBrands (c);

		request.setAttribute("styles, result", result);

		RequestDispatcher view = request.getRequestDispatcher("result.jsp");

		view.forward(request, response);
		}
}
