package com.example.web;

public class HttpServlet {

}
