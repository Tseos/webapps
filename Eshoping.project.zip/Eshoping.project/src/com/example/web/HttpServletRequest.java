package com.example.web;

import java.util.List;

public class HttpServletRequest {

	public RequestDispatcher getRequestDispatcher(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAttribute(String string, List<String> result) {
		// TODO Auto-generated method stub
		
	}

	public String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
