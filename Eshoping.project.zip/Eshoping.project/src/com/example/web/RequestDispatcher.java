package com.example.web;

public class RequestDispatcher {

	public void forward(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

}
