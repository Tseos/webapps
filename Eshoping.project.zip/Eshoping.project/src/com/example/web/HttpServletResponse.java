package com.example.web;

public class HttpServletResponse {

}
