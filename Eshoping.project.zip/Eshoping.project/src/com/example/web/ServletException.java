package com.example.web;

public class ServletException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
